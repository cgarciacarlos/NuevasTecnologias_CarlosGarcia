dias_semana= ("Lunes", "Martes","Miercoles","Jueves","Viernes","Sabado","Domingo")
print(type(dias_semana))

#funcion Len -> mide el tamano
print(len(dias_semana))

print(dias_semana[0])
print(dias_semana[1])
print(dias_semana[2])
print(dias_semana[3])
print(dias_semana[4])
print(dias_semana[5])
print(dias_semana[6])

# Podemos hacer slicing indicando el rango que queremos imprimir
# este es un slicing [:posicion]
print(dias_semana[:7])
print(dias_semana[0:])
print(dias_semana[-1:])
print(dias_semana[:-1])
print(dias_semana[2:5])

# para recorrer la tupla usamos For

for i in range(len(dias_semana)):
    print(dias_semana[i])

    # Para cambiar algun valor de la Tupla o agreagr debemos, primero convertirla
    # a una lista:

    dias_semana_lista= list(dias_semana)
    print(type(dias_semana_lista))
    dias_semana_lista.append("festivo")
    print(dias_semana_lista[:8])
    dias_semana_lista.pop()
    print(dias_semana_lista[:8])

    dias_semana=tuple(dias_semana_lista)
    print(type(dias_semana))

    

#son inmutables, es decir no se puede modificar de entrada su contenido
#Contienen distintos tipos de datos
#si se requiere adicionar algo a una tupla, se tiene que convertir primero a una lista
#Se puede acceder la tupla indicando el indice de la misma, el cual comienza desde cero
# Para recorrer la Tupla usamos el ciclo FOR
# Podemos hacer Joins entre Tuplas
# Para conocer el tamano usamos la funcion Len(dias_semana)
