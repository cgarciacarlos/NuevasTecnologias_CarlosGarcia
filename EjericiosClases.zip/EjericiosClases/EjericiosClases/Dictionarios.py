# Los diccionarios permiten tener clave: valor
# Son cambiables
# No permiten duplicados
# Desde Python 3.7 son ordenados
# Permite agregar, remover Items
# Son iterables
# Poseen distintos metodos para manipular los datos
# Admite distintos tipos de datos

usuario= {"nombre":"Pepito", "apellido:": "Perez",
          "edad": 25}

print(usuario)

#Imprime las claves
print(usuario.keys())

#Imprime los valores
print(usuario.values())

#Para conocer el tamano del diccionario usamos el metodo Len()

print(len(usuario))
print(type(usuario))

# Cuando queremos buscar un item en especifico podemos usar get()

print(usuario.get("nombre"))
print(usuario["edad"])

#Podemos agregar nuevos items

usuario["correo"] = "Pepito@mail.com"
print(usuario.get("correo"))
print(usuario.keys())

usuario.update({"correo":"pperez@mail.com"})
print(usuario.get("correo"))


# Para remover
"""usuario.pop("nombre")
print(usuario.keys())
usuario.popitem()
print(usuario.keys())
del usuario ["edad"]
print(usuario.keys())"""

for x,y in usuario.items():
    print(x,y)
# Recorrer las claves

# Asi trae solo las claves, nombre, apellido, etc
for x in usuario.keys():
    print(x)

for y in usuario.values():
    print(y)


# Podemos tener un diccionario de diccionarios

usuarios = {"usuario1":{"nombre":"Juan", "edad":12}, "usuario2":{"nombre":"Maria", "edad":15,},
"usuario3": {"nombre": "Julia", "edad":18}}

estudiantes1 = {"nota1":4.5, "nota2":4.3}
estudiantes2 = {"nota1":4.4, "nota2":4.3}
estudiantes3 = {"nota1":4.5, "nota2":4.1}

estudiantes = {
    "estudiantes1":estudiantes1,
    "estudiantes2":estudiantes2,
    "estudiantes3":estudiantes3
}

print(estudiantes["estudiantes2"]["nota2"])
